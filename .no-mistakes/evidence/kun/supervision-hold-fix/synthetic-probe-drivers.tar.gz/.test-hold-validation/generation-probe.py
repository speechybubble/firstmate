import subprocess,pathlib,json,shutil,signal,os
root=pathlib.Path.cwd();home=root/'.test-hold-validation/generation'
shutil.rmtree(home)
for name in ['state','data','config','agent']:(home/name).mkdir(parents=True)
shutil.copyfile(root/'.tasks.toml',home/'.tasks.toml');(home/'data/backlog.md').write_text('## In flight\n\n## Queued\n\n## Done\n')
env={'PATH':'/home/denni/.local/bin:/usr/bin:/bin','FM_HOME':str(home),'FM_ROOT_OVERRIDE':str(root),'FM_GATE_REFUSE_BYPASS':'1','PI_CODING_AGENT_DIR':str(home/'agent'),'PI_OFFLINE':'1','PI_TELEMETRY':'0','TMPDIR':str(root/'.test-hold-validation/tmp')}
cmd=['/bin/bash','-c','printf "%s\\n" "$$" > "$FM_HOME/state/.lock"; exec pi --mode rpc --offline --no-extensions --no-skills --no-context-files --no-prompt-templates --no-themes --approve --provider openai-codex --model gpt-6-astra --thinking high --session-dir "$FM_HOME/sessions" -e "$FM_ROOT_OVERRIDE/.pi/extensions/fm-branch-supervision.ts" -e "$FM_ROOT_OVERRIDE/.test-hold-validation/generation-probe.ts"']
p=subprocess.Popen(cmd,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
p.stdin.write(json.dumps({'id':'generation','type':'prompt','message':'/probe-generation'})+'\n');p.stdin.flush()
try:p.wait(timeout=50)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM)
out,err=p.communicate(timeout=10)
evidence=pathlib.Path('/home/denni/kun-validation/firstmate-hold-nm/evidence/01M2S2425JRHW58D43GETYG2M4/live-pi-generation.log');evidence.write_text(out+err)
print(p.returncode,out,err)
assert p.returncode==0 and '"result":"pass"' in err
