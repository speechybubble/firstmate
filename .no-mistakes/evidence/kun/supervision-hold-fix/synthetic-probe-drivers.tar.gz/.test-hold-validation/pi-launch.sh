#!/bin/bash
printf '%s\n' "$$" > "$FM_HOME/state/.lock"
exec pi --mode rpc --offline --no-extensions --no-skills --no-context-files --no-prompt-templates --no-themes --approve --provider openai-codex --model gpt-6-astra --thinking high --session-dir "$FM_HOME/sessions" -e "$FM_ROOT_OVERRIDE/.pi/extensions/fm-branch-supervision.ts" -e "$FM_ROOT_OVERRIDE/.test-hold-validation/pi-probe.ts"
