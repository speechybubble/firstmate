import pathlib,subprocess,os,json,shutil,signal,time
root=pathlib.Path.cwd(); lab=root/'.test-hold-validation/watch';lab.mkdir()
for mode in ['signal','stale','unreadable']:
 home=lab/mode
 for name in ['state','data','config','agent','fakebin','project']:(home/name).mkdir(parents=True)
 shutil.copyfile(root/'.tasks.toml',home/'.tasks.toml')
 (home/'data/backlog.md').write_text('## In flight\n\n## Queued\n\n## Done\n')
 env={'PATH':f'{home}/fakebin:/home/denni/.local/bin:/usr/bin:/bin','FM_HOME':str(home),'FM_STATE_OVERRIDE':str(home/'state'),'FM_ROOT_OVERRIDE':str(root),'FM_GATE_REFUSE_BYPASS':'1','PI_CODING_AGENT_DIR':str(home/'agent'),'PI_OFFLINE':'1','PI_TELEMETRY':'0','TERM':'xterm-256color','FM_POLL':'1','FM_SIGNAL_GRACE':'0','FM_HEARTBEAT':'999999','PROBE_MODE':mode,'TMPDIR':str(root/'.test-hold-validation/tmp')}
 (home/'fakebin/bash').write_text('#!/bin/bash\nif [[ ${1:-} = -lc ]]; then shift; exec /bin/bash -c "$@"; fi\nexec /bin/bash "$@"\n')
 (home/'fakebin/bash').chmod(0o755)
 (home/'fakebin/tmux').write_text('''#!/bin/bash
case "$1" in
list-windows) echo fm-task-a ;;
capture-pane) printf 'Synthetic stopped worker\\n> \\n' ;;
display-message) echo bash ;;
*) exit 1 ;;
esac
''');(home/'fakebin/tmux').chmod(0o755)
 (home/'state/task-a.meta').write_text(f'window=sess:fm-task-a\nbackend=tmux\nkind=ship\nharness=codex\nmodel=gpt-6-astra\neffort=high\nproject={home}/project\nworktree={home}/project\n')
 (home/'state/task-b.meta').write_text(f'window=sess:fm-task-b\nproject={home}/project\n')
 subprocess.run(['/bin/bash',str(root/'bin/fm-captain-hold.sh'),'hold','task-a','--title','Synthetic held task','--reason','Intentional stop'],env=env,check=True,capture_output=True)
 # Unrelated unread row is durable before the held task wakes.
 subprocess.run(['/bin/bash','-c','. "$1/bin/fm-wake-lib.sh"; fm_wake_append signal task-b.turn-ended "signal: task-b.turn-ended"','bash',str(root)],env=env,check=True,capture_output=True)
 if mode!='stale':(home/'state/task-a.turn-ended').touch()
 if mode=='unreadable':(home/'data/backlog.md').chmod(0)
 launch=['/bin/bash','-c','printf "%s\\n" "$$" > "$FM_HOME/state/.lock"; exec pi --mode rpc --offline --no-extensions --no-skills --no-context-files --no-prompt-templates --no-themes --approve --provider openai-codex --model gpt-6-astra --thinking high --session-dir "$FM_HOME/sessions" -e "$FM_ROOT_OVERRIDE/.pi/extensions/fm-branch-supervision.ts" -e "$FM_ROOT_OVERRIDE/.pi/extensions/fm-primary-pi-watch.ts" -e "$FM_ROOT_OVERRIDE/.test-hold-validation/watch-probe.ts"']
 p=subprocess.Popen(launch,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 try:
  for _ in range(600):
   if (home/'ready').exists():break
   if p.poll() is not None:break
   time.sleep(.1)
  assert (home/'ready').exists(),'No expected main wake'
  p.stdin.write(json.dumps({'id':'finish','type':'prompt','message':'/probe-finish'})+'\n');p.stdin.flush()
  p.wait(timeout=15)
  out,err=p.communicate(timeout=10)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);out,err=p.communicate(timeout=10);print(json.dumps({'mode':mode,'timeout':True,'stdout':out,'stderr':err}),flush=True);raise
 finally:
  if mode=='unreadable':(home/'data/backlog.md').chmod(0o600)
 print(json.dumps({'mode':mode,'exit':p.returncode,'stdout':out,'stderr':err}),flush=True)
 rows=[]
 for line in (out+err).splitlines():
  try:rows.append(json.loads(line))
  except:pass
 expected='stale:' if mode=='stale' else 'signal:'
 inputs=[r for r in rows if 'mainInput' in r and f'FIRSTMATE WATCHER WAKE: {expected}' in r['mainInput']]
 assert len(inputs)==1,(mode,out,err)
 r=inputs[0];assert r['source']=='extension' and r['noWorkerStatus'] and r['grantAbsent']
 assert r['offers'] and all(not o['eligible'] and not o['accepted'] for o in r['offers'])
 assert f'FIRSTMATE WATCHER WAKE: {"stale" if mode=="stale" else "signal"}:' in r['mainInput']
 assert 'task-b.turn-ended' in r['queue'] and 'task-a' in r['queue']
print(json.dumps({'result':'pass','runtime':'real Pi primary watcher, branch extension, watcher CLI and hold predicate; model input intercepted using Pi input API'}))
