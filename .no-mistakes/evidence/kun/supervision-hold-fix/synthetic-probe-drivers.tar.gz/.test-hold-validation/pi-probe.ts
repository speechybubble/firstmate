import { readFileSync, writeFileSync, existsSync, mkdirSync, chmodSync, rmSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { createBranchDispatchOffer, scopeForUnreadWakeWithHolds } from '../.pi/extensions/lib/fm-branch-dispatch.ts';
export default function(pi) {
 pi.on('session_start', async () => {
  const root = process.env.FM_ROOT_OVERRIDE!;
  const home = process.env.FM_HOME!;
  const state = `${home}/state`;
  const log = (obj) => { console.log(JSON.stringify(obj)); };
  const run = (script, ...args) => execFileSync('/bin/bash', [`${root}/bin/${script}`, ...args], {encoding:'utf8'});
  try {
   for (const task of ['task-a','task-b']) writeFileSync(`${state}/${task}.meta`, `project=${home}/project\nwindow=fm-${task}\n`);
   writeFileSync(`${home}/decision.txt`, 'Resume the synthetic task.\n');
   for (const kind of ['signal','stale']) {
    for (const race of ['after-acceptance','async-two-task']) {
     const key = kind === 'signal' ? 'task-a.turn-ended' : 'fm-task-a';
     const msg = `${kind}: ${key}`;
     const queued = `1\t1\t${kind}\t${key}\t${msg}\n1\t2\tsignal\ttask-b.turn-ended\tsignal: task-b.turn-ended\n`;
     writeFileSync(`${state}/.wake-queue`,queued);
     const initial = await scopeForUnreadWakeWithHolds(state,false,root,home);
     if (initial.eligibleSeqs.join(',') !== '1,2') throw Error('Initial rows not eligible');
     if (race === 'async-two-task') writeFileSync(`${home}/race-armed`,'');
     const offer = createBranchDispatchOffer(msg,initial.projects,false,true);
     pi.events.emit('fm-branch-supervision:dispatch',offer);
     if (!offer.accepted) throw Error('Real Pi branch did not accept');
     const settled = offer.settlement.then(() => null, (e) => e);
     if (race === 'after-acceptance') run('fm-captain-hold.sh','hold','task-a','--title','Synthetic task A','--reason','Stopped after acceptance');
     const failure = await settled;
     if (!failure || !/captain decision|eligible row snapshot/.test(failure.message)) throw Error(`Wrong settlement: ${failure}`);
     if (readFileSync(`${state}/.wake-queue`,'utf8') !== queued || existsSync(`${state}/.branch-eligible-rows`)) throw Error('Grant consumed or retained rows');
     if (race === 'async-two-task' && (!existsSync(`${home}/first-read`) || existsSync(`${home}/race-armed`))) throw Error('Race not exercised');
     const drain = spawnSync('/bin/bash',[`${root}/bin/fm-wake-drain.sh`],{encoding:'utf8'});
     if (drain.status !== 0 || !drain.stdout.includes(`\t${kind}\t${key}\t`) || !drain.stdout.includes('\tsignal\ttask-b.turn-ended\t')) throw Error(`Main drain failed: ${drain.stdout} ${drain.stderr}`);
     log({scenario:race,kind,accepted:offer.accepted,branchRejection:failure.message,noStatus:!existsSync(`${state}/task-a.status`),queuePreserved:true,mainDrain:drain.stdout,ack:drain.stderr});
     const recovery = drain.stderr.match(/--recovery-generation (\S+)/)?.[1];
     run('fm-wake-drain.sh','--ack-through','2','--recovery-generation',recovery!);
     run('fm-captain-hold.sh','answer','task-a','--release','--decision-file',`${home}/decision.txt`);
     rmSync(`${home}/first-read`,{force:true});
    }
   }
   log({result:'pass',runtime:'real Pi CLI and installed SDK; no providers called'});
   process.exit(0);
  } catch(e) { log({result:'fail',error:String(e),stack:e.stack}); process.exit(1); }
 });
}
