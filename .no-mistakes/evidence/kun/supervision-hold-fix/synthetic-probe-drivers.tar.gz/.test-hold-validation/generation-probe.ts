import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createBranchDispatchOffer, scopeForUnreadWakeWithHolds } from '../.pi/extensions/lib/fm-branch-dispatch.ts';
export default function(pi) {
 pi.registerCommand('probe-generation',{description:'Exercise isolated session replacement',handler:async(_args,ctx)=>{
  const root=process.env.FM_ROOT_OVERRIDE!,home=process.env.FM_HOME!,state=`${home}/state`;
  try {
   writeFileSync(`${state}/task-a.meta`,`project=${home}/project\nwindow=fm-task-a\n`);
   const queue='1\t1\tsignal\ttask-a.turn-ended\tsignal: task-a.turn-ended\n';
   writeFileSync(`${state}/.wake-queue`,queue);
   const scope=await scopeForUnreadWakeWithHolds(state,false,root,home);
   const offer=createBranchDispatchOffer('signal: task-a.turn-ended',scope.projects,false,scope.eligible);
   pi.events.emit('fm-branch-supervision:dispatch',offer);
   if(!offer.accepted)throw Error('Old session did not accept');
   const settlement=offer.settlement.then(()=>null,e=>e);
   const replaced=await ctx.newSession();
   const failure=await settlement;
   if(replaced.cancelled || !failure || !/replaced|no longer owns/.test(failure.message))throw Error(`Wrong replacement outcome: ${failure}`);
   if(existsSync(`${state}/.branch-eligible-rows`) || readFileSync(`${state}/.wake-queue`,'utf8')!==queue)throw Error('Old session changed queue');
   console.log(JSON.stringify({scenario:'real Pi session replacement after acceptance',replaced,branchRejection:failure.message,queuePreserved:true,grantAbsent:true}));
   console.log(JSON.stringify({result:'pass'}));
   process.exit(0);
  }catch(e){console.log(JSON.stringify({result:'fail',error:String(e)}));process.exit(1);}
 }});
}
