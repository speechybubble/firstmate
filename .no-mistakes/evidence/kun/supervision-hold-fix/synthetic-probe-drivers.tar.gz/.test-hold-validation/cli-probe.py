import os,pathlib,subprocess,json,time,shutil
root=pathlib.Path.cwd(); lab=root/'.test-hold-validation/cli'; home=lab/'home'; state=home/'state'; fake=lab/'fakebin'
for p in (state,home/'config',home/'data',fake):p.mkdir(parents=True,exist_ok=True)
shutil.copyfile(root/'.tasks.toml',home/'.tasks.toml')
(home/'data/backlog.md').write_text('## In flight\n\n## Queued\n\n## Done\n')
(state/'.lock').write_text(str(os.getpid())+'\n')
for task in ('t1','t2'):(state/f'{task}.meta').write_text(f'window=sess:fm-{task}\nkind=ship\nharness=codex\nmodel=gpt-6-astra\neffort=high\nbackend=tmux\nproject={home}/project\n')
(fake/'tmux').write_text('''#!/bin/bash
printf '%s\\n' "$*" >> "$FM_HOME/transport.log"
case "$1" in
send-keys)
 if [[ -e "$FM_HOME/pause-transport" ]]; then
  touch "$FM_HOME/transport-paused"
  for ((i=0;i<1500;i++)); do
   [[ ! -e "$FM_HOME/pause-transport" ]] && break
   /bin/sleep .01
  done
 fi ;;
display-message) echo fakepane ;;
capture-pane) printf '╭────╮\\n│    │\\n╰────╯\\n' ;;
list-windows) printf 'fm-t1\\nfm-t2\\n' ;;
esac
exit 0
'''); (fake/'tmux').chmod(0o755)
env={'PATH':f'{fake}:/home/denni/.local/bin:/usr/bin:/bin','FM_HOME':str(home),'FM_ROOT_OVERRIDE':str(root),'FM_STATE_OVERRIDE':str(state),'FM_GATE_REFUSE_BYPASS':'1','FM_SEND_SETTLE':'0','FM_SEND_SLEEP':'0','PI_CODING_AGENT':'true','FM_LEASE_HOLDER_PID':str(os.getpid()),'TMPDIR':str(root/'.test-hold-validation/tmp')}
def emit(**data):print(json.dumps(data),flush=True)
def cmd(script,*args,branch=False,code=0):
 e=env|({'FM_SUPERVISION_ACTOR':'branch'} if branch else {})
 r=subprocess.run(['/bin/bash',str(root/'bin'/script),*args],env=e,capture_output=True,text=True,timeout=60)
 emit(command=[script,*args],actor='branch' if branch else 'main',exit=r.returncode,stdout=r.stdout,stderr=r.stderr)
 assert r.returncode==code,(script,r.returncode,code,r.stdout,r.stderr)
 return r

def hold(reason):cmd('fm-captain-hold.sh','hold','t1','--title','Synthetic worker','--reason',reason)
def release():
 (home/'decision.txt').write_text('Resume the synthetic bounded task.\n')
 cmd('fm-captain-hold.sh','answer','t1','--release','--decision-file',str(home/'decision.txt'))
def inbox():return sorted(p.name for p in (state/'t1.inbox').glob('*.msg'))
def start(script,*args,branch=False):
 return subprocess.Popen(['/bin/bash',str(root/'bin'/script),*args],env=env|({'FM_SUPERVISION_ACTOR':'branch'} if branch else {}),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def complete(p,label):
 out,err=p.communicate(timeout=60);emit(concurrentCommand=label,exit=p.returncode,stdout=out,stderr=err);assert p.returncode==0

def waitfor(pred):
 for i in range(2000):
  if pred():return
  time.sleep(.01)
 raise AssertionError('Timed out waiting for barrier')
cmd('fm-lease.sh','claim','t1')
hold('Intentional stop while main owns lease')
cmd('fm-lease.sh','release','t1')
cmd('fm-lease.sh','claim','t1',branch=True)
cmd('fm-send.sh','t1','Forbidden held continuation',branch=True,code=6)
cmd('fm-control.sh','t1','relaunch',branch=True,code=6)
assert inbox()==[] and not (home/'transport.log').exists() and not (state/'t1.status').exists()
emit(scenario='held steer and relaunch after main releases lease',inbox=inbox(),transportAbsent=True,workerStatusAbsent=True)
cmd('fm-lease.sh','release','t1',branch=True)
cmd('fm-send.sh','t1','--key','Escape')
emit(scenario='main stop while held',transport=(home/'transport.log').read_text())
release()
cmd('fm-send.sh','t1','Authorized after release',branch=True)
assert inbox()==['001.msg']
emit(scenario='release restores steering',record=(state/'t1.inbox/001.msg').read_text())
(state/'.wake-queue').write_text('1\t1\tsignal\tt1.turn-ended\tsignal: t1.turn-ended\n1\t2\tsignal\tt2.turn-ended\tsignal: t2.turn-ended\n')
cmd('fm-wake-grant.sh','activate',str(os.getpid()),'probe')
cmd('fm-wake-grant.sh','publish','probe','--tasks','t1','t2','--rows','1','2')
hold('Stop after grant')
cmd('fm-send.sh','t1','Forbidden old-grant continuation',branch=True,code=6)
assert inbox()==['001.msg']
emit(scenario='post-grant hold blocks mutation',grantedRows=(state/'.branch-eligible-rows').read_text(),inbox=inbox())
cmd('fm-wake-grant.sh','release','probe')
(home/'data/backlog.md').chmod(0)
try:
 cmd('fm-send.sh','t1','Indeterminate hold',branch=True,code=6)
 cmd('fm-wake-grant.sh','publish','probe','--tasks','t1','t2','--rows','1','2',code=1)
 assert inbox()==['001.msg'] and not (state/'.branch-eligible-rows').exists()
 emit(scenario='unreadable authority fails closed',inbox=inbox(),grantAbsent=True)
finally:(home/'data/backlog.md').chmod(0o600)
release()
# Hold cannot overtake a send already inside its task-control lock.
(home/'pause-transport').touch()
sender=start('fm-send.sh','t1','Serialized before hold',branch=True)
waitfor(lambda:(home/'transport-paused').exists())
assert (state/'.control-t1.lock').exists()
holder=start('fm-captain-hold.sh','hold','t1','--reason','Hold serialized behind send')
time.sleep(.3); assert holder.poll() is None
emit(scenario='send wins synchronization',holdWaiting=True,controlLockPresent=True,inbox=inbox())
(home/'pause-transport').unlink(); complete(sender,'branch send'); complete(holder,'main hold')
cmd('fm-send.sh','t1','Forbidden after serialized hold',branch=True,code=6)
assert inbox()==['001.msg','002.msg']
release()
# Hold cannot overtake a grant blocked after final validation at the queue lock.
blocker=subprocess.Popen(['/bin/bash','-c','. "$1/bin/fm-wake-lib.sh"; fm_lock_acquire_wait "$FM_WAKE_QUEUE_LOCK"; touch "$FM_HOME/queue-blocked"; read -r release; fm_lock_release "$FM_WAKE_QUEUE_LOCK"','bash',str(root)],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
waitfor(lambda:(home/'queue-blocked').exists())
grant=start('fm-wake-grant.sh','publish','probe','--tasks','t2','t1','--rows','1','2')
waitfor(lambda:all((state/f'.control-{t}.lock').exists() for t in ('t1','t2')))
time.sleep(.3)
holder=start('fm-captain-hold.sh','hold','t1','--reason','Hold serialized behind grant')
time.sleep(.3);assert holder.poll() is None and grant.poll() is None and not (state/'.branch-eligible-rows').exists()
emit(scenario='grant retains task locks until publication',holdWaiting=True,grantWaitingForQueue=True)
blocker.stdin.write('release\n');blocker.stdin.flush();complete(blocker,'queue lock release');complete(grant,'grant publication');complete(holder,'hold after publication')
assert (state/'.branch-eligible-rows').read_text()=='1\n2\n'
assert not any((state/f'.control-{t}.lock').exists() for t in ('t1','t2'))
cmd('fm-send.sh','t1','Forbidden after grant serialization',branch=True,code=6)
cmd('fm-wake-grant.sh','release','probe')
cmd('fm-wake-grant.sh','publish','wrong-generation','--tasks','t2','--rows','2',code=1)
assert not (state/'.branch-eligible-rows').exists()
emit(scenario='stale grant generation rejected',queue=(state/'.wake-queue').read_text())
# Active main lease still prevents branch delivery even for an unheld task.
cmd('fm-lease.sh','claim','t2')
cmd('fm-send.sh','t2','Forbidden while main owns task',branch=True,code=6)
cmd('fm-lease.sh','release','t2')
emit(result='pass',runtime='real CLI; synthetic terminal transport; no worker launched')
