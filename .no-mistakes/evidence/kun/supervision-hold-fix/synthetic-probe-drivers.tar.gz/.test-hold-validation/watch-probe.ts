import { readFileSync, existsSync, writeFileSync } from 'node:fs';
export default function(pi) {
 const offers:any[]=[];
 pi.registerCommand('probe-finish',{description:'Finish isolated probe',handler:async(_args,ctx)=>ctx.shutdown()});
 pi.events.on('fm-branch-supervision:dispatch', (offer) => {
  offers.push(offer);
  console.log(JSON.stringify({offer:offer.message,eligible:offer.eligible,accepted:offer.accepted}));
 });
 pi.on('input', (event,ctx) => {
  console.log(JSON.stringify({mainInput:event.text,source:event.source,mode:process.env.PROBE_MODE,offers:offers.map(o=>({message:o.message,eligible:o.eligible,accepted:o.accepted})),queue:readFileSync(`${process.env.FM_HOME}/state/.wake-queue`,'utf8'),noWorkerStatus:!existsSync(`${process.env.FM_HOME}/state/task-a.status`),grantAbsent:!existsSync(`${process.env.FM_HOME}/state/.branch-eligible-rows`)}));
  const expected=process.env.PROBE_MODE === 'stale' ? 'stale:' : 'signal:';
  if(event.text.includes(`FIRSTMATE WATCHER WAKE: ${expected}`)) writeFileSync(`${process.env.FM_HOME}/ready`,'');
  return {action:'handled'};
 });
}
